<?php
    /**
     * Your Twitter App Info
     */
    
    // Consumer Key
    define('CONSUMER_KEY', 'Kp5BSOA2hr2x3XZ4Mb83UcicZ');
    define('CONSUMER_SECRET', 'ZGIxQO3M8oxT1d7jpPdMVo2Slqml3DSV5hL2JEr6YvTyUw1g6O');

    // User Access Token
    define('ACCESS_TOKEN', '2649180637-NYq4urMNsGi7FKdCNiTaPINbeIxXyHyKz73dqNI');
    define('ACCESS_SECRET', 'QPh5GcOhKstPgAUNA7HAwszRKtL9H4HhVNi22310DSPlS');

	// Cache Settings
    define('CACHE_ENABLED', false);
	define('CACHE_LIFETIME', 3600); // in seconds
	define('HASH_SALT', md5(dirname(__FILE__)));
