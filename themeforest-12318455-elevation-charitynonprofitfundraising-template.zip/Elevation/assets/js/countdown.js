jQuery(document).ready(function($) {

    "use strict";

    jQuery("#time_countdown1").countDown({

     targetDate: {
       'day':    10,
       'month':  10,
       'year':   2017,
       'hour':   11,
       'min':    0,
       'sec':    0
   },
   omitWeeks: true
});

    jQuery("#time_countdown2").countDown({

     targetDate: {
       'day': 1,
       'month': 12,
       'year': 2016,
       'hour': 0,
       'min': 0,
       'sec': 0
   },
   omitWeeks: true
});

    jQuery("#time_countdown3").countDown({

     targetDate: {
       'day': 1,
       'month': 12,
       'year': 2020,
       'hour': 0,
       'min': 0,
       'sec': 0
   },
    //   omitWeeks: true
});

    jQuery("#time_countdown4").countDown({

     targetDate: {
       'day': 1,
       'month': 12,
       'year': 2020,
       'hour': 0,
       'min': 0,
       'sec': 0
   },
    //   omitWeeks: true
});

    jQuery("#time_countdown5").countDown({

     targetDate: {
       'day': 1,
       'month': 12,
       'year': 2020,
       'hour': 0,
       'min': 0,
       'sec': 0
   },
   //    omitWeeks: true
});

   //    $("#time_countdown-6").countDown({

   //       targetDate: {
   //         'day': 1,
   //         'month': 12,
   //         'year': 2020,
   //         'hour': 0,
   //         'min': 0,
   //         'sec': 0
   //     },
   // //    omitWeeks: true
   //    });

jQuery("#time_countdown7").countDown({

 targetDate: {
   'day': 1,
   'month': 12,
   'year': 2020,
   'hour': 0,
   'min': 0,
   'sec': 0
},
   //    omitWeeks: true
});

jQuery("#time_countdown8").countDown({

 targetDate: {
   'day': 1,
   'month': 12,
   'year': 2020,
   'hour': 0,
   'min': 0,
   'sec': 0
},
   //    omitWeeks: true
});

jQuery("#time_countdown9").countDown({

 targetDate: {
   'day': 1,
   'month': 12,
   'year': 2020,
   'hour': 0,
   'min': 0,
   'sec': 0
},
  //     omitWeeks: true
});

});