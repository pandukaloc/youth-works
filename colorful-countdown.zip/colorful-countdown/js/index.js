var $countdown = document.querySelector('#countdown');
var countdown = parseInt($countdown.getAttribute('data-start'));
var countdownHandler = function countdownHandler(i) {
  if (countdown > 0) {
    $countdown.classList.add('start');
    $countdown.setAttribute('data-countdown', countdown);
    countdown--;
  } else if (countdown == 0) {
    $countdown.setAttribute('data-countdown', countdown);
    $countdown.classList.remove('start');
    countdown--;
  } else if (countdown == -1) {
    countdown--;
    clearInterval(countdownInterval);
  }
};

var countdownInterval = setInterval(countdownHandler, 1000);

document.querySelector('#restart').addEventListener('click', function () {
  countdown = parseInt($countdown.getAttribute('data-start'));
  countdownInterval = setInterval(countdownHandler, 1000);
});